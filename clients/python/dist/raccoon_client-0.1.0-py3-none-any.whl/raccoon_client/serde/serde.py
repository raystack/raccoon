class Serde:
    def serialise(self, event):
        raise NotImplementedError()
