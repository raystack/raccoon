class Serde:  # pylint: disable=too-few-public-methods
    def serialise(self, event):
        raise NotImplementedError()
